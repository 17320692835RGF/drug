"use client";

import React, { useEffect, useMemo, useState } from "react";
import type { CSSProperties, ReactNode } from "react";
import {
  AnimalSection,
  HumanActivitySection,
  InVitroSection,
  groupBiodistributionRows,
  renderValue,
  type AnimalInVivo,
  type HumanActivity,
  type InVitro,
} from "@/app/components/activity-sections";
import { getEntityCategoryColor, PRIMARY_COLOR } from "@/lib/entity-category-colors";
import { buildAssetUrl } from "@/lib/assets";

function getLightEntityCategoryColor(category: string) {
  const map: Record<string, string> = {
    cold_compound: "#dcfce7",
    ligand: "#dbeafe",
    linker: "#fef3c7",
    chelator: "#ffedd5",
    radionuclide: "#ede9fe",
  };
  return map[category] ?? "#e0f2fe";
}

type Basic = {
  entity_category: string;
  entity_id: string;
  external_id: string | null;
  name: string | null;
  synonyms: string | null;
  smiles: string | null;
  formula: string | null;
  structure_image: string | null;
  mol2d_path: string | null;
  mol3d_path: string | null;
  pubchem_cid: string | null;
  inchi: string | null;
  inchikey: string | null;
  iupac_name: string | null;
  molecular_weight: number | null;
  complexity: number | null;
  heavy_atom_count: number | null;
  hbond_acceptors: number | null;
  hbond_donors: number | null;
  rotatable_bonds: number | null;
  logp: number | null;
  tpsa: number | null;
  ligand_type: string | null;
  linker_type: string | null;
  radionuclide_symbol: string | null;
  radionuclide_half_life: string | null;
  radionuclide_emission: string | null;
  radionuclide_energy: string | null;
};

type RdcActivity = {
  drug_id: string;
  drug_name: string;
  status: string | null;
  type: string | null;
  human_activity?: HumanActivity[];
  animal_in_vivo?: AnimalInVivo;
  in_vitro?: InVitro;
};

type RdcSummary = {
  drug_id: string;
  drug_name: string;
  status: string | null;
  compound_name: string | null;
  ligand_name: string | null;
  linker_name: string | null;
  chelator_name: string | null;
  radionuclide_name: string | null;
};

type AffinityItem = {
  affinity_id: string;
  affinity_type: string | null;
  affinity_symbols: string | null;
  affinity_value: string | null;
  affinity_unit: string | null;
  description: string | null;
  source: string | null;
};

type ChemicalDetail = {
  basic?: Basic;
  rdc_activity?: RdcActivity[];
  rdcs?: RdcSummary[];
  affinity?: AffinityItem[];
};

// Related RDCs Visualization Component
function RelatedRdcGraph({
  entityCategory,
  basic,
  rdcs,
  mainColor,
  lightColor,
}: {
  entityCategory: string;
  basic: Basic | undefined;
  rdcs: RdcSummary[];
  mainColor: string;
  lightColor: string;
}) {
  const entityName = basic?.name || basic?.entity_id || "";
  const [openRelated, setOpenRelated] = useState(true);
  const [hoveredDrug, setHoveredDrug] = useState<RdcSummary | null>(null);
  const [hoveredCenter, setHoveredCenter] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 0, y: 0 });

  const handleMouseMove = (e: React.MouseEvent) => {
    setMousePos({ x: e.clientX, y: e.clientY });
  };

  const drugPositions = useMemo(() => {
    if (rdcs.length === 0) return [];
    const radius = 180;
    const centerX = 250;
    const centerY = 250;
    return rdcs.map((drug, index) => {
      const angle = (index / rdcs.length) * 2 * Math.PI - Math.PI / 2;
      return {
        ...drug,
        x: centerX + radius * Math.cos(angle),
        y: centerY + radius * Math.sin(angle),
        angle,
      };
    });
  }, [rdcs]);

  const tooltipStyle: CSSProperties = {
    position: "fixed",
    left: mousePos.x + 15,
    top: mousePos.y + 15,
    background: "#fff",
    border: "2px solid #1F2937",
    borderRadius: 8,
    padding: 12,
    boxShadow: "0 4px 12px rgba(0,0,0,0.15)",
    zIndex: 1000,
    minWidth: 200,
    pointerEvents: "none",
  };

  // Build center tooltip content based on entity category
  const renderCenterTooltip = () => {
    if (!basic) return null;
    const rows: { label: string; value: string }[] = [];

    switch (entityCategory) {
      case "radionuclide":
        rows.push(
          { label: "Radionuclide ID", value: basic.entity_id },
          { label: "Name", value: basic.name || "-" },
          { label: "Symbol", value: basic.radionuclide_symbol || "-" },
          { label: "Half Life", value: basic.radionuclide_half_life || "-" },
          { label: "Emission", value: basic.radionuclide_emission || "-" },
          { label: "Energy", value: basic.radionuclide_energy || "-" }
        );
        break;
      case "chelator":
        rows.push(
          { label: "Chelator ID", value: basic.entity_id },
          { label: "Name", value: basic.name || "-" },
          { label: "Formula", value: basic.formula || "-" },
          { label: "Molecular Weight", value: basic.molecular_weight?.toString() || "-" }
        );
        break;
      case "ligand":
        rows.push(
          { label: "Ligand ID", value: basic.entity_id },
          { label: "Name", value: basic.name || "-" },
          { label: "Ligand-Type", value: basic.ligand_type || "-" },
          { label: "External ID", value: basic.external_id || "-" },
          { label: "Formula", value: basic.formula || "-" }
        );
        break;
      case "linker":
        rows.push(
          { label: "Linker ID", value: basic.entity_id },
          { label: "Name", value: basic.name || "-" },
          { label: "Linker-type", value: basic.linker_type || "-" }
        );
        break;
      case "cold_compound":
        rows.push(
          { label: "Cold Compound ID", value: basic.entity_id },
          { label: "Name", value: basic.name || "-" },
          { label: "Formula", value: basic.formula || "-" },
          { label: "Molecular Weight", value: basic.molecular_weight?.toString() || "-" }
        );
        break;
      default:
        rows.push(
          { label: "ID", value: basic.entity_id },
          { label: "Name", value: basic.name || "-" }
        );
    }

    return (
      <>
        <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 8, color: "#0f172a" }}>
          {entityName}
        </div>
        <div style={{ fontSize: 12, color: "#475569", lineHeight: 1.6 }}>
          {rows.map((r) => (
            <div key={r.label}><strong>{r.label}:</strong> {r.value}</div>
          ))}
        </div>
      </>
    );
  };

  return (
    <>
      <section
        style={{
          marginTop: 16,
          background: "#F8FAFC",
          border: `1px solid ${mainColor}`,
          borderRadius: 10,
          overflow: "hidden",
        }}
      >
        <div
          onClick={() => setOpenRelated((v) => !v)}
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            padding: "10px 12px",
            background: lightColor,
            color: mainColor,
            fontWeight: 700,
            cursor: "pointer",
          }}
        >
          <span>Related RDCs ({rdcs.length})</span>
          <span style={{ fontSize: 16 }}>{openRelated ? "▾" : "▸"}</span>
        </div>
        {openRelated && (
          <div style={{ padding: 24, background: "#fff", display: "flex", justifyContent: "center" }}>
            <svg width={500} height={500} onMouseMove={handleMouseMove}>
              {/* Lines to drugs */}
              {drugPositions.map((drug, index) => (
                <line
                  key={`line-${index}`}
                  x1={250}
                  y1={250}
                  x2={drug.x}
                  y2={drug.y}
                  stroke="#9ca3af"
                  strokeWidth={1}
                />
              ))}

              {/* Drug circles - white with #C2C0D9 border */}
              {drugPositions.map((drug, index) => {
                let rotationAngle = (drug.angle * 180) / Math.PI;
                const isRightSide = Math.cos(drug.angle) >= 0;
                if (!isRightSide) {
                  // rotationAngle += 180;
                }
                return (
                  <g key={`drug-${index}`}>
                    <circle
                      cx={drug.x}
                      cy={drug.y}
                      r={5}
                      fill="#ffffff"
                      stroke="#C2C0D9"
                      strokeWidth={2}
                      style={{ cursor: "pointer" }}
                      onMouseEnter={() => setHoveredDrug(drug)}
                      onMouseLeave={() => setHoveredDrug(null)}
                      onClick={() => window.open(`/rdc/${drug.drug_id}`, "_blank")}
                    />
                    <text
                      x={drug.x}
                      y={drug.y}
                      textAnchor="start"
                      dominantBaseline="middle"
                      fill="#1F2937"
                      fontSize={8}
                      fontWeight={600}
                      transform={`rotate(${rotationAngle}, ${drug.x}, ${drug.y}) translate(8, 0)`}
                      style={{ pointerEvents: "none" }}
                    >
                      {drug.drug_id}
                    </text>
                  </g>
                );
              })}

              {/* Invisible center area for hover */}
              <circle
                cx={250}
                cy={250}
                r={40}
                fill="transparent"
                stroke="none"
                style={{ cursor: "pointer" }}
                onMouseEnter={() => setHoveredCenter(true)}
                onMouseLeave={() => setHoveredCenter(false)}
              />
            </svg>
          </div>
        )}
      </section>

      {/* Tooltip for drug nodes */}
      {hoveredDrug && !hoveredCenter && (
        <div style={tooltipStyle}>
          <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 8, color: "#0f172a" }}>
            {hoveredDrug.drug_name || entityName}
          </div>
          <div style={{ fontSize: 12, color: "#475569", lineHeight: 1.6 }}>
            <div><strong>ID:</strong> {hoveredDrug.drug_id || "-"}</div>
            <div><strong>Name:</strong> {hoveredDrug.drug_name || entityName}</div>
            <div><strong>Status:</strong> {hoveredDrug.status ?? "-"}</div>
            <div><strong>Cold Compound:</strong> {hoveredDrug.compound_name ?? "-"}</div>
            <div><strong>Ligand:</strong> {hoveredDrug.ligand_name ?? "-"}</div>
            <div><strong>Linker:</strong> {hoveredDrug.linker_name ?? "-"}</div>
            <div><strong>Chelator:</strong> {hoveredDrug.chelator_name ?? "-"}</div>
            <div><strong>Radionuclide:</strong> {hoveredDrug.radionuclide_name ?? "-"}</div>
          </div>
        </div>
      )}

      {/* Tooltip for center */}
      {hoveredCenter && (
        <div style={tooltipStyle}>
          {renderCenterTooltip()}
        </div>
      )}
    </>
  );
}

type FieldBoxProps = {
  label: string;
  value: ReactNode;
  style?: CSSProperties;
};

const fieldBoxStyle: CSSProperties = {
  border: "1px dashed #f59e0b",
  borderRadius: 8,
  padding: 8,
};

function FieldBox({ label, value, style }: FieldBoxProps) {
  return (
    <div style={{ ...fieldBoxStyle, ...style }}>
      <div style={{ color: "#16a34a", fontWeight: 600, fontSize: 14 }}>{label}</div>
      <div style={{ color: "#111827", marginTop: 4, fontSize: 14 }}>{renderValue(value)}</div>
    </div>
  );
}

function RdcActivityCard({ activity }: { activity: RdcActivity }) {
  const [openHuman, setOpenHuman] = useState(true);
  const [openHumanItems, setOpenHumanItems] = useState<Record<number, boolean>>({});
  const [openAnimal, setOpenAnimal] = useState(true);
  const [openBiodistItems, setOpenBiodistItems] = useState<Record<number, boolean>>({});
  const [openInVitro, setOpenInVitro] = useState(true);
  const [open, setOpen] = useState(true);

  const biodistGroups = useMemo(
    () => groupBiodistributionRows((activity.animal_in_vivo?.studies ?? []).flatMap((s) => s.biodistribution ?? [])),
    [activity.animal_in_vivo?.studies]
  );

  useEffect(() => {
    const next: Record<number, boolean> = {};
    (activity.human_activity ?? []).forEach((_, i) => {
      next[i] = true;
    });
    setOpenHumanItems(next);
  }, [activity.human_activity]);

  useEffect(() => {
    setOpenBiodistItems((prev) => {
      const next: Record<number, boolean> = { ...prev };
      biodistGroups.forEach((_, i) => {
        if (!(i in next)) next[i] = true;
      });
      Object.keys(next)
        .map((k) => Number(k))
        .forEach((i) => {
          if (i >= biodistGroups.length) delete next[i];
        });
      return next;
    });
  }, [biodistGroups]);

  return (
    <div style={{ overflow: "hidden" }}>
      <div
        onClick={() => setOpen((v) => !v)}
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          padding: "8px",
          background: "#1fa1a8",
          color: "#fff",
          cursor: "pointer",
          borderRadius: "4px"
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 10, fontWeight: 700 }}>
          <span style={{ fontSize: 16 }}>{open ? "▾" : "▸"}</span>
          <span style={{ fontSize: 15 }}>
            {activity.drug_name} [{activity.status ?? "-"}]
          </span>
        </div>
        <a
          href={`/rdc/${activity.drug_id}`}
          target="_blank"
          rel="noreferrer"
          style={{
            padding: "6px 12px",
            background: PRIMARY_COLOR,
            boxShadow: "4px 3px 0 0 #565656",
            color: "#fff",
            borderRadius: 8,
            textDecoration: "none",
            fontSize: 14,
            fontWeight: 700,
          }}
          onClick={(e) => e.stopPropagation()}
        >
          RDC Info
        </a>
      </div>

      {open && (
        <div style={{ display: "grid" }}>

          <HumanActivitySection
            items={activity.human_activity ?? []}
            open={openHuman}
            onToggle={() => setOpenHuman((v) => !v)}
            openItems={openHumanItems}
            onToggleItem={(idx) => setOpenHumanItems((prev) => ({ ...prev, [idx]: !(prev[idx] ?? true) }))}
          />

          <AnimalSection
            animal={activity.animal_in_vivo}
            open={openAnimal}
            onToggle={() => setOpenAnimal((v) => !v)}
            openBiodistItems={openBiodistItems}
            onToggleBiodistItem={(idx) => setOpenBiodistItems((prev) => ({ ...prev, [idx]: !(prev[idx] ?? true) }))}
          />

          <InVitroSection data={activity.in_vitro} open={openInVitro} onToggle={() => setOpenInVitro((v) => !v)} />
        </div>
      )}
    </div>
  );
}

export default function ChemicalDetailPage({
  params,
}: {
  params: { entity_category: string; entity_id: string };
}) {
  const { entity_category, entity_id } = params;
  const mainColor = getEntityCategoryColor(entity_category);
  const lightColor = getLightEntityCategoryColor(entity_category);
  const isSummaryOnlyCategory =
    entity_category === "ligand" || entity_category === "chelator" || entity_category === "radionuclide";

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [detail, setDetail] = useState<ChemicalDetail | null>(null);
  const [rdcListData, setRdcListData] = useState<RdcSummary[]>([]);
  const [openBasic, setOpenBasic] = useState(true);
  const [openRdcSection, setOpenRdcSection] = useState(true);
  const [openAffinity, setOpenAffinity] = useState(true);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      setLoading(true);
      setError(null);
      try {
        // Fetch main detail data
        const detailUrl = `/api/chemical/${encodeURIComponent(entity_category)}/${encodeURIComponent(
          entity_id
        )}?include_activity=true`;
        const detailRes = await fetch(detailUrl, { cache: "no-store" });
        if (!detailRes.ok) {
          const err = await detailRes.json().catch(() => ({}));
          throw new Error(err?.message || `HTTP ${detailRes.status}`);
        }
        const detailData = (await detailRes.json()) as ChemicalDetail;
        if (!cancelled) setDetail(detailData);

        // Fetch rdc-list for graph / table
        const listUrl = `/api/chemical/${encodeURIComponent(entity_category)}/${encodeURIComponent(
          entity_id
        )}/rdc-list`;
        const listRes = await fetch(listUrl, { cache: "no-store" });
        if (listRes.ok) {
          const listData = (await listRes.json()) as ChemicalDetail;
          if (!cancelled) setRdcListData(listData.rdcs ?? []);
          // For summary-only categories, also merge rdcs into detail
          if (isSummaryOnlyCategory && !cancelled) {
            setDetail((prev) =>
              prev ? { ...prev, rdcs: listData.rdcs ?? [] } : prev
            );
          }
        }
      } catch (e: any) {
        if (!cancelled) setError(e?.message || String(e));
      } finally {
        if (!cancelled) setLoading(false);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, [entity_category, entity_id, isSummaryOnlyCategory]);

  const basic = detail?.basic;
  const rdcActivity = detail?.rdc_activity ?? [];
  const rdcList = detail?.rdcs ?? [];
  const externalIdValue = typeof basic?.external_id === "string" ? basic.external_id.trim() : "";
  const externalIdDisplay =
    entity_category === "ligand" && externalIdValue ? (
      <a
        href={`https://www.imgt.org/mAb-DB/mAbcard?AbId=${encodeURIComponent(externalIdValue)}`}
        target="_blank"
        rel="noreferrer"
        style={{ color: "#0ea5e9", fontWeight: 700, textDecoration: "none", overflowWrap: "anywhere" }}
      >
        {externalIdValue} ↗
      </a>
    ) : (
      basic?.external_id ?? "-"
    );

  const basicCommonRows: Array<[string, ReactNode]> = [
    ["entity_category", basic?.entity_category ?? "-"],
    ["entity_id", basic?.entity_id ?? "-"],
    ["external_id", externalIdDisplay],
    ["name", basic?.name ?? "-"],
    ...(entity_category === "ligand"
      ? [["ligand_type", basic?.ligand_type ?? "-"] as [string, ReactNode]]
      : []),
    ...(entity_category === "linker"
      ? [["linker_type", basic?.linker_type ?? "-"] as [string, ReactNode]]
      : []),
    ["synonyms", basic?.synonyms ?? "-"],
  ];

  const basicNonRadionuclideRows: Array<[string, ReactNode]> = [
    ["smiles", basic?.smiles ?? "-"],
    ["formula", basic?.formula ?? "-"],
    ["pubchem_cid", basic?.pubchem_cid ?? "-"],
    ["inchi", basic?.inchi ?? "-"],
    ["inchikey", basic?.inchikey ?? "-"],
    ["iupac_name", basic?.iupac_name ?? "-"],
    ["molecular_weight", basic?.molecular_weight ?? "-"],
    ["complexity", basic?.complexity ?? "-"],
    ["heavy_atom_count", basic?.heavy_atom_count ?? "-"],
    ["hbond_acceptors", basic?.hbond_acceptors ?? "-"],
    ["hbond_donors", basic?.hbond_donors ?? "-"],
    ["rotatable_bonds", basic?.rotatable_bonds ?? "-"],
    ["logp", basic?.logp ?? "-"],
    ["tpsa", basic?.tpsa ?? "-"],
  ];

  const basicRadionuclideRows: Array<[string, ReactNode]> = [
    ["radionuclide_symbol", basic?.radionuclide_symbol ?? "-"],
    ["radionuclide_half_life", basic?.radionuclide_half_life ?? "-"],
    ["radionuclide_emission", basic?.radionuclide_emission ?? "-"],
    ["radionuclide_energy", basic?.radionuclide_energy ?? "-"],
  ];

  const basicRows: Array<[string, ReactNode]> =
    entity_category === "radionuclide"
      ? [...basicCommonRows, ...basicRadionuclideRows]
      : [...basicCommonRows, ...basicNonRadionuclideRows];

  return (
    <main>
      {/* <h1 style={{ margin: 0 }}>Chemical Entity Detail</h1>
      <p style={{ marginTop: 6, color: "#475569" }}>
        Category: {entity_category} | Entity ID: {entity_id}
      </p> */}

      {error && <p style={{ color: "#b91c1c" }}>Error: {error}</p>}
      {loading && <p>Loading…</p>}

      {!!basic && (
        <section
          style={{
            marginTop: 16,
            background: "#F8FAFC",
            border: `1px solid ${mainColor}`,
            borderRadius: 10,
            overflow: "hidden",
          }}
        >
          <div
            onClick={() => setOpenBasic((v) => !v)}
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              padding: "10px 12px",
              background: lightColor,
              color: mainColor,
              fontWeight: 700,
              cursor: "pointer",
            }}
          >
            <span>General Information of this {entity_category}  </span>
            <span style={{ fontSize: 16 }}>{openBasic ? "▾" : "▸"}</span>
          </div>
          {openBasic && (
            <div style={{ display: "grid", gap: 12, padding: 12, background: "#fff" }}>
              {(() => {
                const showStructureSection = entity_category !== "radionuclide";
                const structureName =
                  typeof basic.structure_image === "string" && basic.structure_image
                    ? `${basic.structure_image}`
                    : null;
                const structureUrl = buildAssetUrl(structureName, "structure");
                const mol2dName = typeof basic.mol2d_path === "string" && basic.mol2d_path ? basic.mol2d_path : null;
                const mol3dName = typeof basic.mol3d_path === "string" && basic.mol3d_path ? basic.mol3d_path : null;
                const mol2d = buildAssetUrl(mol2dName, "rdc_2d", "cdxml");
                const mol3d = buildAssetUrl(mol3dName, "rdc_3d", "sdf");
                return (
                  <div style={{ width: "100%", overflowX: "auto" }}>
                    <table style={{ width: "100%", minWidth: 360, borderCollapse: "collapse" }}>
                      <tbody>
                        {basicRows.map(([label, value], i, arr) => {
                          const row = (
                            <tr key={label}>
                              <td
                                style={{
                                  padding: "9px 12px",
                                  borderTop: i === 0 ? "1px solid #d4d4d8" : "1px solid #e5e7eb",
                                  borderBottom: i === arr.length - 1 ? "1px solid #d4d4d8" : "1px solid #e5e7eb",
                                  width: "24%",
                                  fontWeight: 700,
                                  color: "#0f172a",
                                  fontSize: 14,
                                  wordBreak: "break-word",
                                }}
                              >
                                {label}
                              </td>
                              <td
                                style={{
                                  padding: "9px 12px",
                                  borderTop: i === 0 ? "1px solid #d4d4d8" : "1px solid #e5e7eb",
                                  borderBottom: i === arr.length - 1 ? "1px solid #d4d4d8" : "1px solid #e5e7eb",
                                  color: "#0f172a",
                                  fontSize: 14,
                                  lineHeight: 1.5,
                                  wordBreak: "break-word",
                                }}
                              >
                                {renderValue(value)}
                              </td>
                            </tr>
                          );

                          if (label !== "synonyms" || !showStructureSection) {
                            return row;
                          }

                          return (
                            <React.Fragment key={label}>
                              {row}
                              <tr>
                                <td
                                  style={{
                                    padding: "12px",
                                    borderTop: "1px solid #e5e7eb",
                                    borderBottom: "1px solid #e5e7eb",
                                    width: "24%",
                                    fontWeight: 700,
                                    color: "#0f172a",
                                    fontSize: 14,
                                    verticalAlign: "top",
                                    wordBreak: "break-word",
                                  }}
                                >
                                  Structure
                                </td>
                                <td
                                  style={{
                                    borderTop: "1px solid #e5e7eb",
                                    borderBottom: "1px solid #e5e7eb",
                                    color: "#0f172a",
                                    fontSize: 14,
                                    lineHeight: 1.5,
                                    wordBreak: "break-word",
                                  }}
                                >
                                  <div
                                    style={{
                                      borderRadius: 10,
                                      padding: 12,
                                      display: "grid",
                                      gap: 10,
                                    }}
                                  >
                                    <div
                                      style={{
                                        minHeight: 220,
                                        border: "1px solid #e5e7eb",
                                        borderRadius: 8,
                                        background: "#fff",
                                        display: "flex",
                                        alignItems: "center",
                                        justifyContent: "center",
                                        padding: 12,
                                      }}
                                    >
                                    {structureUrl ? (
                                      <img
                                        src={structureUrl}
                                        alt="structure"
                                        style={{
                                          width: "100%",
                                          height: "100%",
                                          maxWidth: "min(766px, 100%)",
                                            objectFit: "contain",
                                            borderRadius: 4,
                                          }}
                                        />
                                      ) : (
                                        <span style={{ color: "#94a3b8" }}>No structure image</span>
                                      )}
                                    </div>
                                    <div style={{ height: 1, background: "#e2e8f0", margin: "4px 0" }} />
                                    <div style={{ display: "flex", justifyContent: "center", gap: 40, flexWrap: "wrap" }}>
                                      {mol3d ? (
                                        <a
                                          href={mol3d}
                                          download
                                          style={{
                                            display: "inline-flex",
                                            alignItems: "center",
                                            gap: 6,
                                            color: "#0f9e9e",
                                            fontWeight: 700,
                                            textDecoration: "none",
                                          }}
                                        >
                                          <span style={{ fontSize: 18 }}>⬇</span>
                                          <span>3D SDF</span>
                                        </a>
                                      ) : (
                                        <span style={{ color: "#94a3b8" }}>3D SDF not available</span>
                                      )}
                                      {mol2d ? (
                                        <a
                                          href={mol2d}
                                          download
                                          style={{
                                            display: "inline-flex",
                                            alignItems: "center",
                                            gap: 6,
                                            color: "#0f9e9e",
                                            fontWeight: 700,
                                            textDecoration: "none",
                                          }}
                                        >
                                          <span style={{ fontSize: 18 }}>⬇</span>
                                          <span>2D MOL</span>
                                        </a>
                                      ) : (
                                        <span style={{ color: "#94a3b8" }}>2D MOL not available</span>
                                      )}
                                    </div>
                                  </div>
                                </td>
                              </tr>
                            </React.Fragment>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                );
              })()}
            </div>
          )}
        </section>
      )}

      {!isSummaryOnlyCategory && (
        <section
          style={{
            marginTop: 16,
            background: "#F8FAFC",
            border: `1px solid ${mainColor}`,
            borderRadius: 10,
            overflow: "hidden",
          }}
        >
          <div
            onClick={() => setOpenRdcSection((v) => !v)}
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              padding: "10px 12px",
              background: lightColor,
              color: mainColor,
              fontWeight: 700,
              cursor: "pointer",
            }}
          >
            <span>Full Information of The Activity Data of The RDC(s) Related to This {entity_category} </span>
            <span style={{ fontSize: 16 }}>{openRdcSection ? "▾" : "▸"}</span>
          </div>

          {openRdcSection && (
            <div
              style={{
                display: "grid",
                gap: 14,
                padding: 10,
              }}
            >
              {rdcActivity.map((activity) => (
                <RdcActivityCard key={activity.drug_id} activity={activity} />
              ))}
              {rdcActivity.length === 0 && (
                <div style={{ color: "#64748b", padding: 8 }}>No RDC activity found for this chemical entity.</div>
              )}
            </div>
          )}
        </section>
      )}

      {(entity_category === "ligand" || entity_category === "cold_compound") && (
        <section
          style={{
            marginTop: 16,
            background: "#F8FAFC",
            border: `1px solid ${mainColor}`,
            borderRadius: 10,
            overflow: "hidden",
          }}
        >
          <div
            onClick={() => setOpenAffinity((v) => !v)}
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              padding: "10px 12px",
              background: lightColor,
              color: mainColor,
              fontWeight: 700,
              cursor: "pointer",
            }}
          >
            <span>The Activity Data of This {entity_category === "ligand" ? "Ligand" : "Cold Compound"}</span>
            <span style={{ fontSize: 16 }}>{openAffinity ? "▾" : "▸"}</span>
          </div>
          {openAffinity && (
            <div style={{ padding: 12, background: "#fff" }}>
              {detail?.affinity && detail.affinity.length > 0 ? detail.affinity.map((item) => (
                <div
                  key={item.affinity_id}
                  style={{
                    marginBottom: 16,
                    border: "1px solid #e5e7eb",
                    borderRadius: 8,
                    overflow: "hidden",
                  }}
                >
                  <div
                    style={{
                      padding: "10px 12px",
                      background: "#f1f5f9",
                      fontWeight: 700,
                      fontSize: 15,
                      color: "#0f172a",
                    }}
                  >
                    {entity_category === "ligand" ? "Ligand Activity information" : "Cold Compound Activity information"}
                  </div>
                  <div style={{ padding: 12 }}>
                    <table style={{ width: "100%", borderCollapse: "collapse" }}>
                      <tbody>
                        <tr>
                          <td
                            style={{
                              padding: "8px 12px",
                              width: "24%",
                              fontWeight: 700,
                              color: "#0f172a",
                              fontSize: 14,
                              borderBottom: "1px solid #e5e7eb",
                              wordBreak: "break-word",
                            }}
                          >
                            Affinity-ID
                          </td>
                          <td
                            style={{
                              padding: "8px 12px",
                              color: "#0f172a",
                              fontSize: 14,
                              borderBottom: "1px solid #e5e7eb",
                              wordBreak: "break-word",
                            }}
                          >
                            {item.affinity_id}
                          </td>
                        </tr>
                        <tr>
                          <td
                            style={{
                              padding: "8px 12px",
                              width: "24%",
                              fontWeight: 700,
                              color: "#0f172a",
                              fontSize: 14,
                              wordBreak: "break-word",
                            }}
                          >
                            Affinity-Type
                          </td>
                          <td
                            style={{
                              padding: "8px 12px",
                              color: "#0f172a",
                              fontSize: 14,
                              wordBreak: "break-word",
                            }}
                          >
                            <div style={{ display: "flex", flexWrap: "wrap", gap: "16px 24px" }}>
                              <span>{item.affinity_type ?? "-"}</span>
                              <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                                <span style={{ fontWeight: 700 }}>affinity-symbols</span>
                                <span>{item.affinity_symbols ?? "-"}</span>
                              </div>
                              <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                                <span style={{ fontWeight: 700 }}>affinity_value</span>
                                <span>{item.affinity_value ?? "-"}</span>
                              </div>
                              <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
                                <span style={{ fontWeight: 700 }}>affinity_unit</span>
                                <span>{item.affinity_unit ?? "-"}</span>
                              </div>
                            </div>
                          </td>
                        </tr>
                        {item.description && (
                          <tr>
                            <td
                              style={{
                                padding: "8px 12px",
                                width: "24%",
                                fontWeight: 700,
                                color: "#0f172a",
                                fontSize: 14,
                                borderTop: "1px solid #e5e7eb",
                                wordBreak: "break-word",
                              }}
                            >
                              description
                            </td>
                            <td
                              style={{
                                padding: "8px 12px",
                                color: "#0f172a",
                                fontSize: 14,
                                borderTop: "1px solid #e5e7eb",
                                wordBreak: "break-word",
                              }}
                            >
                              {item.description}
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              )) : (
                <div style={{ padding: "8px 12px", color: "#6b7280", fontSize: 14 }}>
                  No activity data available.
                </div>
              )}
            </div>
          )}
        </section>
      )}

      {isSummaryOnlyCategory && (
        <>
          <RelatedRdcGraph
            entityCategory={entity_category}
            basic={basic}
            rdcs={rdcList}
            mainColor={mainColor}
            lightColor={lightColor}
          />
          <section
            style={{
              marginTop: 16,
              background: "#F8FAFC",
              border: `1px solid ${mainColor}`,
              borderRadius: 10,
              overflow: "hidden",
            }}
          >
            <div
              onClick={() => setOpenRdcSection((v) => !v)}
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                padding: "10px 12px",
                background: lightColor,
                color: mainColor,
                fontWeight: 700,
                cursor: "pointer",
              }}
            >
              <span>Complete List of RDCs Related to This {entity_category.charAt(0).toUpperCase() + entity_category.slice(1)}</span>
              <span style={{ fontSize: 16 }}>{openRdcSection ? "▾" : "▸"}</span>
            </div>

            {openRdcSection && (
              <div
                style={{
                  padding: 12,
                  background: "#fff",
                }}
              >
                <div
                  style={{
                    overflow: "hidden",
                    background: "#fff",
                  }}
                >
                  <div
                    style={{
                      padding: "8px 12px",
                      fontWeight: 700,
                      fontSize: 14,
                      display: "flex",
                      alignItems: "center",
                      justifyContent: "space-between",
                    }}
                  >
                  </div>
                  <div style={{ overflowX: "auto" }}>
                    <table
                      style={{
                        width: "100%",
                        borderCollapse: "collapse",
                        minWidth: 720,
                      }}
                    >
                      <thead>
                        <tr>
                          {[
                            "RDC Info",
                            "RDC Name",
                            "cold compound",
                            "ligand",
                            "linker",
                            "chelator",
                            "radionuclide",
                          ].map((label, idx) => (
                            <th
                              key={label}
                              style={{
                                padding: "10px 12px",
                                borderBottom: "1px solid #e5e7eb",
                                textAlign: label === "RDC Info" ? "left" : "center",
                                fontSize: 14,
                                fontWeight: 600,
                                color: "#111827",
                                whiteSpace: "nowrap",
                                position: idx === 0 ? "sticky" as const : undefined,
                                left: idx === 0 ? 0 : undefined,
                                zIndex: idx === 0 ? 2 : undefined,
                                background: idx === 0 ? "#fff" : undefined,
                              }}
                            >
                              {label}
                            </th>
                          ))}
                        </tr>
                      </thead>
                      <tbody>
                        {rdcList.map((item) => (
                          <tr key={item.drug_id}>
                            <td
                              style={{
                                padding: "12px",
                                borderBottom: "1px solid #e5e7eb",
                                position: "sticky",
                                left: 0,
                                zIndex: 1,
                                background: "#fff",
                              }}
                            >
                              <a
                                href={`/rdc/${encodeURIComponent(item.drug_id)}`}
                                target="_blank"
                                rel="noreferrer"
                                style={{
                                  padding: "6px 12px",
                                  background: PRIMARY_COLOR,
                                  borderRadius: 8,
                                  boxShadow: "rgb(86, 86, 86) 4px 3px 0px 0px",
                                  textDecoration: "none",
                                  color: "#fff",
                                  fontSize: 14,
                                  fontWeight: 700,
                                  display: "inline-block",
                                }}
                              >
                                RDC
                              </a>
                            </td>
                            <td
                              style={{
                                padding: "12px",
                                borderBottom: "1px solid #e5e7eb",
                                fontSize: 14,
                                color: "#111827",
                                whiteSpace: "nowrap",
                              }}
                            >
                              {item.drug_name || "-"}
                            </td>
                            <td
                              style={{
                                padding: "12px",
                                borderBottom: "1px solid #e5e7eb",
                                fontSize: 14,
                                color: "#111827",
                                textAlign: "center",
                              }}
                            >
                              {item.compound_name || "-"}
                            </td>
                            <td
                              style={{
                                padding: "12px",
                                borderBottom: "1px solid #e5e7eb",
                                fontSize: 14,
                                color: "#111827",
                                textAlign: "center",
                              }}
                            >
                              {item.ligand_name || "-"}
                            </td>
                            <td
                              style={{
                                padding: "12px",
                                borderBottom: "1px solid #e5e7eb",
                                fontSize: 14,
                                color: "#111827",
                                textAlign: "center",
                              }}
                            >
                              {item.linker_name || "-"}
                            </td>
                            <td
                              style={{
                                padding: "12px",
                                borderBottom: "1px solid #e5e7eb",
                                fontSize: 14,
                                color: "#111827",
                                textAlign: "center",
                              }}
                            >
                              {item.chelator_name || "-"}
                            </td>
                            <td
                              style={{
                                padding: "12px",
                                borderBottom: "1px solid #e5e7eb",
                                fontSize: 14,
                                color: "#111827",
                                textAlign: "center",
                              }}
                            >
                              {item.radionuclide_name || "-"}
                            </td>
                          </tr>
                        ))}
                        {rdcList.length === 0 && (
                          <tr>
                            <td
                              colSpan={7}
                              style={{
                                padding: "14px 12px",
                                textAlign: "center",
                                fontSize: 14,
                                color: "#64748b",
                              }}
                            >
                              No RDC found for this chemical entity.
                            </td>
                          </tr>
                        )}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}
          </section>
        </>
      )}

      {!isSummaryOnlyCategory && rdcListData.length > 0 && (
        <RelatedRdcGraph
          entityCategory={entity_category}
          basic={basic}
          rdcs={rdcListData}
          mainColor={mainColor}
          lightColor={lightColor}
        />
      )}
    </main>
  );
}
